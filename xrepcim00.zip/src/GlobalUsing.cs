// Common namepsaces
global using System;
global using System.Threading;
global using System.Threading.Tasks;

// Project-specific namespaces
global using Ipk25Chat.Debug;
global using Ipk25Chat.Core;
global using Ipk25Chat.IO;
global using Ipk25Chat.Network;